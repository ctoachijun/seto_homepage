<?php
  include "lib/seto.php";

  
  echo "접속?";
  
?>