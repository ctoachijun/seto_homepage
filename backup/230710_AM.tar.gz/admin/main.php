<?
  include "header.php";
  
    
  echo "Welcome. here is main page.";
  
  
  
?>